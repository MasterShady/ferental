setTimeout(() => {
	let cookie = document.cookie.split(';').map(function(v) {
		return v +
			`; expires=${new Date(+new Date + 1000*60*60*10).toGMTString()}; path=/; domain=.qq.com;`
	}).join(',')
	uni.postMessage({
		data: {
			type: 'cookie',
			data: cookie
		}
	})
}, 777)

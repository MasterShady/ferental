var _uniEventDelegation = function(element, eventType, selector, func) {
	element.addEventListener(eventType, function(e) {
		var el = e.target
		while (!el.matches(selector)) {
			if (el === element) {
				el = null
				break;
			}
			el = el.parentNode
		}
		el && func.call(el, el, e)
	})
	return element
}
var _uniReady = function() {
	return new Promise(function(resolve) {
		let timer = setInterval(function() {
			if (window.uni) {
				clearInterval(timer)
				resolve(window.uni)
			}
		}, 16)
	})
}
var _getNative = function(type, data = {}) {
	return new Promise(function(resolve) {
		var apply_id = '_uni_apply_id_' + Math.random().toString(16).substr(2, 6) + +new Date
		window[apply_id] = function(res) {
			try {
				res = JSON.parse(res)
			} catch (e) {}
			resolve(res)
			delete window[apply_id]
		}
		uni.postMessage({
			data: {
				data,
				type,
				apply_id
			}
		});
	})
}

/*window.addEventListener('load', function() {
	_uniEventDelegation(window.document, 'click', 'a', (element, e) => {
		// console.log(element, e)
		var target = element.getAttribute('target')
		if (target === '_blank') {
			e.preventdefault()
			plus.runtime.openURL(
				'https://apps.apple.com/cn/app/id1602652436');
		}
	})
})*/

_uniReady().then(function() {
	window._uni = window.uni;
	window.uni = new Proxy(_uni, {
		get: function(target, prop, receiver) {
			if (prop === 'postMessage') {
				return target[prop]
			}
			return (data) => {
				return _getNative(prop, data)
			}
		},
	});
	window.uni_native = uni;
	window.dispatchEvent(new CustomEvent("uni-ready", {
		bubbles: true,
		cancelable: true
	}))
})

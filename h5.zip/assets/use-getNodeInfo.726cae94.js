import{T as e}from"./index.0a65eeeb.js";const n=n=>{const t=e();return new Promise((e=>{t.select(n).boundingClientRect((function(n){e(n||{})})).exec()}))};export{n as g};

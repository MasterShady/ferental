import{h as o,i}from"./index.7c3f9328.js";function n(n,s,a){o.get(a||i.config.upUserLog,{...n},{_loading:!1})}export{n as u};

import"./index.7c3f9328.js";const e=e=>{const n=uni.createSelectorQuery();return new Promise((t=>{n.select(e).boundingClientRect((function(e){t(e||{})})).exec()}))};export{e as g};

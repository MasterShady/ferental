const o=""+new URL("icon-lock.d9868f92.png",import.meta.url).href;export{o as _};

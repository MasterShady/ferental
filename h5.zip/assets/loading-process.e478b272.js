const e=""+new URL("loading-process.44c09d90.gif",import.meta.url).href;export{e as _};

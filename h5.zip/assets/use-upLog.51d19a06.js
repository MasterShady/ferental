import{h as e,i as o}from"./index.0a65eeeb.js";function i(i,a,n){e.get(n||o.config.upUserLog,{...i},{_loading:!1})}export{i as u};
